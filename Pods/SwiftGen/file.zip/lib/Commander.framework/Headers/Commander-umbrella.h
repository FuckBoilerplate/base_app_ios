#import <Cocoa/Cocoa.h>


FOUNDATION_EXPORT double CommanderVersionNumber;
FOUNDATION_EXPORT const unsigned char CommanderVersionString[];

