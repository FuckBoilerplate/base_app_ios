#import <Cocoa/Cocoa.h>


FOUNDATION_EXPORT double StencilVersionNumber;
FOUNDATION_EXPORT const unsigned char StencilVersionString[];

